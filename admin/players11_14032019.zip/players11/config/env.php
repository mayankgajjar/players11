<?php 
	define("URL", "http://localhost/players11/");
?>