<?php
	include_once 'include/action.php';
	$action = new Action();
	$result_data = $action->cronJob();
	
?>