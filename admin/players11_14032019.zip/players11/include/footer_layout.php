				</div>
			</div>

			<!-- end:: Body -->

			<!-- begin::Footer -->
				<?php  
					include_once 'include/footer.php';
				?>
			<!-- end::Footer -->
		</div>

		<!-- end:: Page -->

		<!-- begin::Scroll Top -->
		<div id="m_scroll_top" class="m-scroll-top">
			<i class="la la-arrow-up"></i>
		</div>

		<!-- end::Scroll Top -->

		<?php include_once 'include/script.php'; ?>
	</body>

	<!-- end::Body -->
</html>