<?php 
	$URL = "http://localhost/players11/";
?>
<!--begin:: Global Mandatory Vendors -->
		
		<script src="<?php echo $URL ?>vendors/js-cookie/src/js.cookie.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/moment/min/moment.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/tooltip.js/dist/umd/tooltip.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/perfect-scrollbar/dist/perfect-scrollbar.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/wnumb/wNumb.js" type="text/javascript"></script>

		<!--end:: Global Mandatory Vendors -->

		<!--begin:: Global Optional Vendors -->
		<script src="<?php echo $URL ?>vendors/jquery.repeater/src/lib.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/jquery.repeater/src/jquery.input.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/jquery.repeater/src/repeater.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/jquery-form/dist/jquery.form.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/block-ui/jquery.blockUI.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/js/framework/components/plugins/forms/bootstrap-datepicker.init.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-datetime-picker/js/bootstrap-datetimepicker.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-timepicker/js/bootstrap-timepicker.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/js/framework/components/plugins/forms/bootstrap-timepicker.init.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-daterangepicker/daterangepicker.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/js/framework/components/plugins/forms/bootstrap-daterangepicker.init.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-maxlength/src/bootstrap-maxlength.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-switch/dist/js/bootstrap-switch.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/js/framework/components/plugins/forms/bootstrap-switch.init.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/vendors/bootstrap-multiselectsplitter/bootstrap-multiselectsplitter.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-select/dist/js/bootstrap-select.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/select2/dist/js/select2.full.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/typeahead.js/dist/typeahead.bundle.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/handlebars/dist/handlebars.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/inputmask/dist/jquery.inputmask.bundle.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/inputmask/dist/inputmask/inputmask.date.extensions.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/inputmask/dist/inputmask/inputmask.numeric.extensions.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/inputmask/dist/inputmask/inputmask.phone.extensions.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/nouislider/distribute/nouislider.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/owl.carousel/dist/owl.carousel.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/autosize/dist/autosize.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/clipboard/dist/clipboard.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/ion-rangeslider/js/ion.rangeSlider.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/dropzone/dist/dropzone.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/summernote/dist/summernote.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/markdown/lib/markdown.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-markdown/js/bootstrap-markdown.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/js/framework/components/plugins/forms/bootstrap-markdown.init.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/jquery-validation/dist/jquery.validate.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/jquery-validation/dist/additional-methods.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/js/framework/components/plugins/forms/jquery-validation.init.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/bootstrap-notify/bootstrap-notify.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/js/framework/components/plugins/base/bootstrap-notify.init.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/toastr/build/toastr.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/jstree/dist/jstree.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/raphael/raphael.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/morris.js/morris.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/chartist/dist/chartist.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/chart.js/dist/Chart.bundle.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/js/framework/components/plugins/charts/chart.init.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/vendors/bootstrap-session-timeout/dist/bootstrap-session-timeout.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/vendors/jquery-idletimer/idle-timer.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/waypoints/lib/jquery.waypoints.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/counterup/jquery.counterup.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/es6-promise-polyfill/promise.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/sweetalert2/dist/sweetalert2.min.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>vendors/js/framework/components/plugins/base/sweetalert2.init.js" type="text/javascript"></script>

		<!--end:: Global Optional Vendors -->

		<!--begin::Global Theme Bundle -->
		<script src="<?php echo $URL ?>assets/demo/base/scripts.bundle.js" type="text/javascript"></script>

		<!--end::Global Theme Bundle -->

		<!--begin::Page Vendors -->
		<script src="<?php echo $URL ?>assets/vendors/custom/fullcalendar/fullcalendar.bundle.js" type="text/javascript"></script>
		<script src="<?php echo $URL ?>assets/vendors/custom/datatables/datatables.bundle.js" type="text/javascript"></script>

		<!--end::Page Vendors -->

		<!--begin::Page Scripts -->
		<script src="<?php echo $URL ?>assets/app/js/dashboard.js" type="text/javascript"></script>
		
		<!--<script src="assets/demo/custom/crud/datatables/extensions/buttons.js" type="text/javascript"></script>-->

		<!--end::Page Scripts -->