<?php include_once 'include/head_layout.php'; ?>

<div class="m-subheader ">
	<div class="d-flex align-items-center">
		<div class="mr-auto">
			<h3 class="m-subheader__title ">Dashboard</h3>
		</div>
	</div>
</div>

<?php include_once 'include/footer_layout.php'; ?>
				